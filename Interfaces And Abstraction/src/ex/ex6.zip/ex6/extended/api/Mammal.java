package ex.ex6.extended.api;

public interface Mammal {
    String getName();
    String getBirthDay();
    boolean wasBornInGivenYear(String year);
}