package paw_inc.entities.centers;

public class AdoptionCenter extends Center {


    public AdoptionCenter(String name) {
        super(name);
    }
}
