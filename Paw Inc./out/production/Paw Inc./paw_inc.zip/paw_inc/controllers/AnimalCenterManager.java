package paw_inc.controllers;

import paw_inc.entities.animals.Animal;
import paw_inc.entities.animals.Cat;
import paw_inc.entities.animals.Dog;
import paw_inc.entities.centers.AdoptionCenter;
import paw_inc.entities.centers.CleansingCenter;
import paw_inc.factories.AnimalFactory;
import paw_inc.factories.CenterFactory;
import paw_inc.io.TerminalWriter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AnimalCenterManager {

    private AnimalFactory animalFactory;
    private CenterFactory centerFactory;
    private HashMap<String, AdoptionCenter> adoptionCentersRegistered;
    private HashMap<String, CleansingCenter> cleansingCentersRegistered;
    private List<Animal> adoptedAnimals;
    private List<Animal> cleansedAnimals;

    public AnimalCenterManager() {
        this.animalFactory = AnimalFactory.getInstance();
        this.centerFactory = CenterFactory.getInstance();
        this.adoptionCentersRegistered = new HashMap<>();
        this.cleansingCentersRegistered = new HashMap<>();
        this.adoptedAnimals = new ArrayList<>();
        this.cleansedAnimals = new ArrayList<>();
    }

    public void registerCleansingCenter(String name) {
        if (!cleansingCentersRegistered.containsKey(name)) {
            CleansingCenter center = new CleansingCenter(name);
            cleansingCentersRegistered.put(name, center);
        }
    }

    public void registerAdoptionCenter(String name) {
        if (!adoptionCentersRegistered.containsKey(name)) {
            AdoptionCenter adoptionCenter = new AdoptionCenter(name);
            adoptionCentersRegistered.put(name, adoptionCenter);
        }
    }

    public void registerDog(String name, int age, int learnedCommands, String adoptionCenterName) {
        if (adoptionCentersRegistered.containsKey(adoptionCenterName)) {
            Dog dog = new Dog(name, age, learnedCommands);
            adoptionCentersRegistered.get(adoptionCenterName).addAnimal(dog);
        }
    }

    public void registerCat(String name, int age, int intelligenceCoefficient, String adoptionCenterName) {
        if (adoptionCentersRegistered.containsKey(adoptionCenterName)) {
            Cat cat = new Cat(name, age, intelligenceCoefficient);
            adoptionCentersRegistered.get(adoptionCenterName).addAnimal(cat);
        }
     }

    public void sendForCleansing(String adoptionCenterName, String cleansingCenterName) {
        if (adoptionCentersRegistered.containsKey(adoptionCenterName) &&
                cleansingCentersRegistered.containsKey(cleansingCenterName)) {
            List<Animal> animals = adoptionCentersRegistered.get(adoptionCenterName).getStoredAnimals();
            for (int i = 0; i < animals.size(); i++) {
                if (animals.get(i).getCleansingStatus() == false) {
                    cleansingCentersRegistered.get(cleansingCenterName).addAnimal(animals.get(i));
                }
            }
        }
    }

    public void cleanse(String cleansingCenterName) {
        if (cleansingCentersRegistered.containsKey(cleansingCenterName)) {
            List<Animal> animals = cleansingCentersRegistered.get(cleansingCenterName).getStoredAnimals();

            for (Map.Entry<String, AdoptionCenter> adoptionCenters : adoptionCentersRegistered.entrySet()) {
                for (int i = 0; i < adoptionCenters.getValue().getStoredAnimals().size(); i++) {
                    if (adoptionCenters.getValue().getStoredAnimals().contains(animals.get(i))) {
                        adoptionCenters.getValue().getStoredAnimals().get(i).setCleansingStatus(true);
                        cleansedAnimals.add(adoptionCenters.getValue().getStoredAnimals().get(i));
                    }
                }
            }
            cleansingCentersRegistered.get(cleansingCenterName).getStoredAnimals().clear();
        }
    }

    public void adopt(String adoptionCenterName) {
        for (int i = 0; i < adoptionCentersRegistered.get(adoptionCenterName).getStoredAnimals().size(); i++) {
            if (adoptionCentersRegistered.get(adoptionCenterName).getAnimal(i).getCleansingStatus() == true) {
                adoptedAnimals.add(adoptionCentersRegistered.get(adoptionCenterName).getAnimal(i));

                adoptionCentersRegistered.get(adoptionCenterName).getStoredAnimals().remove(i);
            }
        }
    }

    public void registerCastrationCenter(String name) {

    }

    public void sendForCastration(String adoptionCenterName, String castrationCenterName) {

    }

    public void castrate(String castrationCenterName) {}

    public void castrationStatistics() {

    }

    public void printStatistics() {
        TerminalWriter.writeLine("Paw Incorporative Regular");
        TerminalWriter.writeLine("Statistics");
        TerminalWriter.writeLine("Adoption Centers: " + adoptionCentersRegistered.size());
        TerminalWriter.writeLine("Cleansing Centers: " + cleansingCentersRegistered.size());
        TerminalWriter.writeLine("Adopted Animals:  " + printAdoptedAnimals());
        TerminalWriter.writeLine("Cleansed Animals:  " + printCleansedAnimals());
        TerminalWriter.writeLine("Animals Awaiting Adoption: " + (cleansedAnimals.size() - adoptedAnimals.size()));
        TerminalWriter.writeLine("Animals Awaiting Cleansing: ");
    }

    private String printAdoptedAnimals() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < adoptedAnimals.size(); i++) {
            sb.append(adoptedAnimals.get(i).getName());
            sb.append(", ");
        }
        return sb.substring(0, sb.length() - 1).toString();
    }

    private String printCleansedAnimals() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < cleansedAnimals.size(); i++) {
            sb.append(cleansedAnimals.get(i).getName());
            sb.append(", ");
        }

        return sb.substring(0, sb.length() - 1).toString();
    }
}
