package cresla;

import cresla.engines.Engine;
import cresla.interfaces.Runnable;
import cresla.repositories.ReactorRepository;
import cresla.repositories.Repository;

import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        Repository repository = new ReactorRepository();
        Runnable engine = new Engine(repository);
        try {
            engine.run();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
