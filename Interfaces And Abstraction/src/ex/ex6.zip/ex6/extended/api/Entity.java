package ex.ex6.extended.api;

public interface Entity {
    String getName();
    String getId();
}