package app.waste_disposal.models.strategies;

import app.waste_disposal.contracts.ProcessingData;
import app.waste_disposal.contracts.Waste;
import app.waste_disposal.models.processing.ProcessingDataImpl;

public class RecyclableStrategy extends AbstractStrategy {
    public RecyclableStrategy() {

    }

    @Override
    public ProcessingData processGarbage(Waste garbage) {
        double totalVolume = garbage.getVolumePerKg() * garbage.getWeight();

        double energyProduced = totalVolume;
        double energyUsed = totalVolume / 5;

        return new ProcessingDataImpl(energyProduced - energyUsed, 0);
    }
}
