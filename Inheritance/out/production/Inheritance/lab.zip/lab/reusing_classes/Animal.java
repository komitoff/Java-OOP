package lab.reusing_classes;

import java.util.List;

public class Animal {
    protected List<Food> foodEaten;

    public void eat(Food food) {

    }

    public void eatAll(Food[] food) {
        for (int i = 0; i < food.length; i++) {
            this.eat(food[i]);
        }
    }
}
