package ex.ex6.extended.api;

public interface Buyer {
    void buyFood();
}