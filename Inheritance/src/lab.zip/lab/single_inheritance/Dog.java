package lab.single_inheritance;

public class Dog extends Animal {
    public void bark() {
        System.out.println("barking...");
    }
}
