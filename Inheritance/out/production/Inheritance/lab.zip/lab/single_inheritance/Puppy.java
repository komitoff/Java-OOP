package lab.single_inheritance;

public class Puppy extends Dog{
    public void weep() {
        System.out.println("weeping…");
    }
}
