package paw_inc.io;

public class TerminalWriter {
    public static void writeLine(String text) {
        System.out.println(text);
    }
}
