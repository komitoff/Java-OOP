package lab.single_inheritance;

public class Cat extends Animal {
    public void meow() {
        System.out.println("meowing…");
    }
}
