package cresla.entities.modules.absorbing;

public class HeatProcessor extends AbstractAbsorbingModule {
    public HeatProcessor(int id, int heatAbsorbing) {
        super(id, heatAbsorbing);
    }
}
