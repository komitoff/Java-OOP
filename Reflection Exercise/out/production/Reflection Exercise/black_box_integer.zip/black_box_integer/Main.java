package black_box_integer;

public class Main {
}
