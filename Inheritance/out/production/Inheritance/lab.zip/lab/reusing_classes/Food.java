package lab.reusing_classes;

public class Food {
}
