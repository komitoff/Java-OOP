package app.waste_disposal.contracts;

import java.io.IOException;

public interface Runnable {
    void run() throws IOException;
}
