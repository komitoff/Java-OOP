package cresla.entities.modules;

import cresla.interfaces.Module;

public abstract class AbstractModule implements Module{

}
