package lab.jar;

public class Pickle {
}
