package need_for_speed;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
//
//        Car car = new PerformanceCar("Trabant", "601",
//                1988, 2000, 1,
//                10000, 1000);
//        CarManager carManager = new CarManager();
//        carManager.register(1, "Show","Trabant", "601",
//                1988, 2000, 1,
//                10000, 1000);
//
//        System.out.println(carManager.check(1));
    }
}
