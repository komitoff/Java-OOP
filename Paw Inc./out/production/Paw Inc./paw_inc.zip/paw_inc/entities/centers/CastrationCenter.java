package paw_inc.entities.centers;

public class CastrationCenter extends Center {

    public CastrationCenter(String name) {
        super(name);
    }
}
