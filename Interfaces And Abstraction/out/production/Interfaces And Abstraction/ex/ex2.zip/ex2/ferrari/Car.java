package ex.ex2.ferrari;

public interface Car {
    String userBreaks();
    String pushTheGasPedal();
}
