package ex.ex2.ferrari;

public interface Car {
    String userBrakes();
    String pushTheGasPedal();
}
