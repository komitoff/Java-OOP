package lab.reusing_classes;

public class Predator extends Animal{
    private int health;

    public void feed(Food food) {

    }

    public final void eat(Food food) {

    }

    public final void eatAll(Food[] food) {
        for (int i = 0; i < food.length; i++) {
            this.eat(food[i]);
        }
    }
}
